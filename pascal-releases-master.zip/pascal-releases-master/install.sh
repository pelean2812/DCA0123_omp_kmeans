#!/bin/sh

sudo cp lib/libapascalops.so /usr/lib/
sudo cp lib/libmpascalops.so /usr/lib/
sudo cp bin/pascalanalyzer /bin
